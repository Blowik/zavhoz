﻿namespace zavhoz
{


    partial class zavhoz_dbDataSet
    {
        partial class nakladnayaDataTable
        {
        }
    }
}
