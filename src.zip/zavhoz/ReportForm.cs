﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zavhoz
{
    public partial class ReportForm : Form
    {
        int id;
        public ReportForm(int id)
        {
            this.id = id;
            InitializeComponent();
        }

        private void ReportForm_Load(object sender, EventArgs e)
        {
            this.nacladnaya_viewTableAdapter.FillById(this.zavhoz_dbDataSet.nacladnaya_view, id);
            this.nacladnaya_pos_viewTableAdapter.FillById(this.zavhoz_dbDataSet.nacladnaya_pos_view, id);
            this.reportViewer1.RefreshReport();
        }
    }
}
