﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zavhoz
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
            cbRabotnik.ComboBox.DataSource = zavhoz_dbDataSet.rabotniki;
            cbRabotnik.ComboBox.DisplayMember = "fio";
            cbRabotnik.ComboBox.ValueMember = "rabotnik_id";
        }

        private void miExit_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void miAbout_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Автоматизированной информационная система для учёт складского оборудования", "О программе", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void miInventar_Click(object sender, EventArgs e)
        {
            new InventarForm().ShowDialog();
        }

        private void miRabotniki_Click(object sender, EventArgs e)
        {
            new RabotnikiForm().ShowDialog();
        }

        private void miDolzhnosti_Click(object sender, EventArgs e)
        {
            new DolzhnostiForm().ShowDialog();
        }

        private void miEdizm_Click(object sender, EventArgs e)
        {
            new EdizmForm().ShowDialog();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            taRabotniki.Fill(this.zavhoz_dbDataSet1.rabotniki);
            nakladnayaTableAdapter.Fill(this.zavhoz_dbDataSet.nakladnaya);
            taRabotniki.Fill(zavhoz_dbDataSet.rabotniki);
            cbRabotnik.ComboBox.SelectedIndex = -1;
        }

        private void cbRabotnik_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbRabotnik.ComboBox.SelectedValue != null)
            {
                int id = (int)cbRabotnik.ComboBox.SelectedValue;
                nalichie_viewTableAdapter.FillByRabotnikId(zavhoz_dbDataSet.nalichie_view, id);
            }
            else
            {
                nalichie_viewTableAdapter.Fill(zavhoz_dbDataSet.nalichie_view);
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            new PeremeschenieForm(-1).ShowDialog();
            nakladnayaTableAdapter.Fill(this.zavhoz_dbDataSet.nakladnaya);
        }

        private void Open_Click(object sender, EventArgs e)
        {
            if (bsNakladnaya.Position >= 0)
            {
                zavhoz_dbDataSet.nakladnayaRow r = (zavhoz_dbDataSet.nakladnayaRow)((DataRowView)bsNakladnaya.Current).Row;
                new PeremeschenieForm(r.doc_id).ShowDialog();
                cbRabotnik_SelectedIndexChanged(null, null);
                nakladnayaTableAdapter.Fill(this.zavhoz_dbDataSet.nakladnaya);
            }
        }

    }
}
