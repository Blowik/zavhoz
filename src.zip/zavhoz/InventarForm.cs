﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zavhoz
{
    public partial class InventarForm : Form
    {
        public InventarForm()
        {
            InitializeComponent();
        }

        private void inventarBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.inventarBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.zavhoz_dbDataSet);

        }

        private void InventarForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'zavhoz_dbDataSet.inventar' table. You can move, or remove it, as needed.
            this.inventarTableAdapter.Fill(this.zavhoz_dbDataSet.inventar);

        }
    }
}
