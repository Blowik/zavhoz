﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zavhoz
{
    public partial class PeremeschenieForm : Form
    {
        int docId;
        public PeremeschenieForm(int docId)
        {
            this.docId = docId;
            InitializeComponent();
        }


        private void PeremeschenieForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'zavhoz_dbDataSet.edizm' table. You can move, or remove it, as needed.
            this.edizmTableAdapter.Fill(this.zavhoz_dbDataSet.edizm);
            // TODO: This line of code loads data into the 'zavhoz_dbDataSet.inventar' table. You can move, or remove it, as needed.
            this.inventarTableAdapter.Fill(this.zavhoz_dbDataSet.inventar);
            rabotnikiTableAdapter.Fill(this.zavhoz_dbDataSet.rabotniki);
            if (docId > 0)
            {
                nakladnaya_pozTableAdapter.FillBy(this.zavhoz_dbDataSet.nakladnaya_poz, docId);
                nakladnayaTableAdapter.FillByDocId(this.zavhoz_dbDataSet.nakladnaya, docId);
                btnSave.Visible = false;
                dgvNakladnayaPoz.ReadOnly = true;
                dgvNakladnayaPoz.AllowUserToAddRows = false;
                dgvNakladnayaPoz.AllowUserToDeleteRows = false;
            }
            else
            {
                bsNakladnaya.AddNew();
                zavhoz_dbDataSet.nakladnayaRow r = (zavhoz_dbDataSet.nakladnayaRow)((DataRowView)bsNakladnaya.Current).Row;
                r.doc_id = GetDocId();
                doc_dateDateTimePicker.Value = DateTime.Now;
                bsNakladnaya.EndEdit();
            }

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                Validate();
                bsNakladnaya.EndEdit();
                tableAdapterManager.UpdateAll(zavhoz_dbDataSet);
                Close();
            } catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private int GetDocId()
        {
            int id;
            string sql = "select max(doc_id)+1 as id from nakladnaya";
            using (SqlConnection connection = new SqlConnection(Properties.Settings.Default.connStr))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);

                id = (int)command.ExecuteScalar();
            }
            return id;
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            zavhoz_dbDataSet.nakladnayaRow r = (zavhoz_dbDataSet.nakladnayaRow)((DataRowView)bsNakladnaya.Current).Row;
            new ReportForm(r.doc_id).Show();
        }
    }
}
