﻿namespace zavhoz
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.zavhoz_dbDataSet = new zavhoz.zavhoz_dbDataSet();
            this.nacladnaya_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nacladnaya_pos_viewBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nacladnaya_viewTableAdapter = new zavhoz.zavhoz_dbDataSetTableAdapters.nacladnaya_viewTableAdapter();
            this.nacladnaya_pos_viewTableAdapter = new zavhoz.zavhoz_dbDataSetTableAdapters.nacladnaya_pos_viewTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.zavhoz_dbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nacladnaya_viewBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nacladnaya_pos_viewBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 350);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(600, 22);
            this.statusStrip1.TabIndex = 0;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.nacladnaya_viewBindingSource;
            reportDataSource2.Name = "DataSet2";
            reportDataSource2.Value = this.nacladnaya_pos_viewBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "zavhoz.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(600, 350);
            this.reportViewer1.TabIndex = 1;
            // 
            // zavhoz_dbDataSet
            // 
            this.zavhoz_dbDataSet.DataSetName = "zavhoz_dbDataSet";
            this.zavhoz_dbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // nacladnaya_viewBindingSource
            // 
            this.nacladnaya_viewBindingSource.DataMember = "nacladnaya_view";
            this.nacladnaya_viewBindingSource.DataSource = this.zavhoz_dbDataSet;
            // 
            // nacladnaya_pos_viewBindingSource
            // 
            this.nacladnaya_pos_viewBindingSource.DataMember = "nacladnaya_pos_view";
            this.nacladnaya_pos_viewBindingSource.DataSource = this.zavhoz_dbDataSet;
            // 
            // nacladnaya_viewTableAdapter
            // 
            this.nacladnaya_viewTableAdapter.ClearBeforeFill = true;
            // 
            // nacladnaya_pos_viewTableAdapter
            // 
            this.nacladnaya_pos_viewTableAdapter.ClearBeforeFill = true;
            // 
            // ReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(783, 533);
            this.Controls.Add(this.reportViewer1);
            this.Controls.Add(this.statusStrip1);
            this.Name = "ReportForm";
            this.Text = "Накладная на внктреннее перемещение";
            this.Load += new System.EventHandler(this.ReportForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.zavhoz_dbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nacladnaya_viewBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nacladnaya_pos_viewBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource nacladnaya_viewBindingSource;
        private zavhoz_dbDataSet zavhoz_dbDataSet;
        private System.Windows.Forms.BindingSource nacladnaya_pos_viewBindingSource;
        private zavhoz_dbDataSetTableAdapters.nacladnaya_viewTableAdapter nacladnaya_viewTableAdapter;
        private zavhoz_dbDataSetTableAdapters.nacladnaya_pos_viewTableAdapter nacladnaya_pos_viewTableAdapter;
    }
}