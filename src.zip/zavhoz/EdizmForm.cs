﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zavhoz
{
    public partial class EdizmForm : Form
    {
        public EdizmForm()
        {
            InitializeComponent();
        }

        private void edizmBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.edizmBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.zavhoz_dbDataSet);

        }

        private void EdizmForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'zavhoz_dbDataSet.edizm' table. You can move, or remove it, as needed.
            this.edizmTableAdapter.Fill(this.zavhoz_dbDataSet.edizm);

        }
    }
}
