﻿namespace zavhoz
{
    partial class DolzhnostiForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DolzhnostiForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.zavhoz_dbDataSet = new zavhoz.zavhoz_dbDataSet();
            this.dolzhnostiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dolzhnostiTableAdapter = new zavhoz.zavhoz_dbDataSetTableAdapters.dolzhnostiTableAdapter();
            this.tableAdapterManager = new zavhoz.zavhoz_dbDataSetTableAdapters.TableAdapterManager();
            this.dolzhnostiBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.dolzhnostiBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.dolzhnostiDataGridView = new System.Windows.Forms.DataGridView();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.zavhoz_dbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dolzhnostiBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dolzhnostiBindingNavigator)).BeginInit();
            this.dolzhnostiBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dolzhnostiDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // zavhoz_dbDataSet
            // 
            this.zavhoz_dbDataSet.DataSetName = "zavhoz_dbDataSet";
            this.zavhoz_dbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dolzhnostiBindingSource
            // 
            this.dolzhnostiBindingSource.DataMember = "dolzhnosti";
            this.dolzhnostiBindingSource.DataSource = this.zavhoz_dbDataSet;
            // 
            // dolzhnostiTableAdapter
            // 
            this.dolzhnostiTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.dolzhnostiTableAdapter = this.dolzhnostiTableAdapter;
            this.tableAdapterManager.edizmTableAdapter = null;
            this.tableAdapterManager.inventarTableAdapter = null;
            this.tableAdapterManager.nakladnaya_pozTableAdapter = null;
            this.tableAdapterManager.nakladnayaTableAdapter = null;
            this.tableAdapterManager.nalichieTableAdapter = null;
            this.tableAdapterManager.rabotnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = zavhoz.zavhoz_dbDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // dolzhnostiBindingNavigator
            // 
            this.dolzhnostiBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.dolzhnostiBindingNavigator.BindingSource = this.dolzhnostiBindingSource;
            this.dolzhnostiBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.dolzhnostiBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.dolzhnostiBindingNavigator.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dolzhnostiBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.dolzhnostiBindingNavigatorSaveItem});
            this.dolzhnostiBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.dolzhnostiBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.dolzhnostiBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.dolzhnostiBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.dolzhnostiBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.dolzhnostiBindingNavigator.Name = "dolzhnostiBindingNavigator";
            this.dolzhnostiBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.dolzhnostiBindingNavigator.Size = new System.Drawing.Size(700, 27);
            this.dolzhnostiBindingNavigator.TabIndex = 0;
            this.dolzhnostiBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(45, 24);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 24);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 24);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 24);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 24);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // dolzhnostiBindingNavigatorSaveItem
            // 
            this.dolzhnostiBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.dolzhnostiBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("dolzhnostiBindingNavigatorSaveItem.Image")));
            this.dolzhnostiBindingNavigatorSaveItem.Name = "dolzhnostiBindingNavigatorSaveItem";
            this.dolzhnostiBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 24);
            this.dolzhnostiBindingNavigatorSaveItem.Text = "Save Data";
            this.dolzhnostiBindingNavigatorSaveItem.Click += new System.EventHandler(this.dolzhnostiBindingNavigatorSaveItem_Click);
            // 
            // dolzhnostiDataGridView
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.dolzhnostiDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dolzhnostiDataGridView.AutoGenerateColumns = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dolzhnostiDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dolzhnostiDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dolzhnostiDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2});
            this.dolzhnostiDataGridView.DataSource = this.dolzhnostiBindingSource;
            this.dolzhnostiDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dolzhnostiDataGridView.Location = new System.Drawing.Point(0, 27);
            this.dolzhnostiDataGridView.Name = "dolzhnostiDataGridView";
            this.dolzhnostiDataGridView.RowTemplate.Height = 32;
            this.dolzhnostiDataGridView.Size = new System.Drawing.Size(700, 349);
            this.dolzhnostiDataGridView.TabIndex = 1;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 376);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(700, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "dolzhnost_id";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "nazvanie";
            this.dataGridViewTextBoxColumn2.HeaderText = "Название должности";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 400;
            // 
            // DolzhnostiForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 398);
            this.Controls.Add(this.dolzhnostiDataGridView);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.dolzhnostiBindingNavigator);
            this.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "DolzhnostiForm";
            this.Text = "Должности";
            this.Load += new System.EventHandler(this.DolzhnostiForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.zavhoz_dbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dolzhnostiBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dolzhnostiBindingNavigator)).EndInit();
            this.dolzhnostiBindingNavigator.ResumeLayout(false);
            this.dolzhnostiBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dolzhnostiDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private zavhoz_dbDataSet zavhoz_dbDataSet;
        private System.Windows.Forms.BindingSource dolzhnostiBindingSource;
        private zavhoz_dbDataSetTableAdapters.dolzhnostiTableAdapter dolzhnostiTableAdapter;
        private zavhoz_dbDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator dolzhnostiBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton dolzhnostiBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView dolzhnostiDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.StatusStrip statusStrip1;
    }
}