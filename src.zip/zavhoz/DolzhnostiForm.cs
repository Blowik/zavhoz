﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zavhoz
{
    public partial class DolzhnostiForm : Form
    {
        public DolzhnostiForm()
        {
            InitializeComponent();
        }

        private void dolzhnostiBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.dolzhnostiBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.zavhoz_dbDataSet);

        }

        private void DolzhnostiForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'zavhoz_dbDataSet.dolzhnosti' table. You can move, or remove it, as needed.
            this.dolzhnostiTableAdapter.Fill(this.zavhoz_dbDataSet.dolzhnosti);

        }
    }
}
