﻿namespace zavhoz
{
    partial class PeremeschenieForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label doc_idLabel;
            System.Windows.Forms.Label doc_dateLabel;
            System.Windows.Forms.Label rabotnik_otLabel;
            System.Windows.Forms.Label rabotnik_kLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PeremeschenieForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnPrint = new System.Windows.Forms.Button();
            this.doc_idTextBox = new System.Windows.Forms.TextBox();
            this.bsNakladnaya = new System.Windows.Forms.BindingSource(this.components);
            this.zavhoz_dbDataSet = new zavhoz.zavhoz_dbDataSet();
            this.doc_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.rabotnik_otComboBox = new System.Windows.Forms.ComboBox();
            this.rabotnikiBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.rabotnik_kComboBox = new System.Windows.Forms.ComboBox();
            this.rabotnikiBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgvNakladnayaPoz = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.inventarBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.edizmBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nakladnaya_pozBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.nakladnayaTableAdapter = new zavhoz.zavhoz_dbDataSetTableAdapters.nakladnayaTableAdapter();
            this.tableAdapterManager = new zavhoz.zavhoz_dbDataSetTableAdapters.TableAdapterManager();
            this.nakladnaya_pozTableAdapter = new zavhoz.zavhoz_dbDataSetTableAdapters.nakladnaya_pozTableAdapter();
            this.rabotnikiBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.rabotnikiTableAdapter = new zavhoz.zavhoz_dbDataSetTableAdapters.rabotnikiTableAdapter();
            this.inventarTableAdapter = new zavhoz.zavhoz_dbDataSetTableAdapters.inventarTableAdapter();
            this.edizmTableAdapter = new zavhoz.zavhoz_dbDataSetTableAdapters.edizmTableAdapter();
            doc_idLabel = new System.Windows.Forms.Label();
            doc_dateLabel = new System.Windows.Forms.Label();
            rabotnik_otLabel = new System.Windows.Forms.Label();
            rabotnik_kLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bsNakladnaya)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zavhoz_dbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotnikiBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotnikiBindingSource2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNakladnayaPoz)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventarBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edizmBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nakladnaya_pozBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotnikiBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // doc_idLabel
            // 
            doc_idLabel.AutoSize = true;
            doc_idLabel.Location = new System.Drawing.Point(42, 31);
            doc_idLabel.Name = "doc_idLabel";
            doc_idLabel.Size = new System.Drawing.Size(60, 20);
            doc_idLabel.TabIndex = 4;
            doc_idLabel.Text = "Номер:";
            // 
            // doc_dateLabel
            // 
            doc_dateLabel.AutoSize = true;
            doc_dateLabel.Location = new System.Drawing.Point(226, 33);
            doc_dateLabel.Name = "doc_dateLabel";
            doc_dateLabel.Size = new System.Drawing.Size(27, 20);
            doc_dateLabel.TabIndex = 6;
            doc_dateLabel.Text = "от:";
            // 
            // rabotnik_otLabel
            // 
            rabotnik_otLabel.AutoSize = true;
            rabotnik_otLabel.Location = new System.Drawing.Point(24, 83);
            rabotnik_otLabel.Name = "rabotnik_otLabel";
            rabotnik_otLabel.Size = new System.Drawing.Size(72, 20);
            rabotnik_otLabel.TabIndex = 8;
            rabotnik_otLabel.Text = "Передал:";
            // 
            // rabotnik_kLabel
            // 
            rabotnik_kLabel.AutoSize = true;
            rabotnik_kLabel.Location = new System.Drawing.Point(351, 85);
            rabotnik_kLabel.Name = "rabotnik_kLabel";
            rabotnik_kLabel.Size = new System.Drawing.Size(72, 20);
            rabotnik_kLabel.TabIndex = 10;
            rabotnik_kLabel.Text = "Получил:";
            // 
            // btnSave
            // 
            this.btnSave.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(455, 455);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(156, 39);
            this.btnSave.TabIndex = 0;
            this.btnSave.Text = "Сохранить";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.Image = ((System.Drawing.Image)(resources.GetObject("btnCancel.Image")));
            this.btnCancel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancel.Location = new System.Drawing.Point(635, 455);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(155, 39);
            this.btnCancel.TabIndex = 0;
            this.btnCancel.Text = "Закрыть";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPrint.Image = global::zavhoz.Properties.Resources.print_icon;
            this.btnPrint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPrint.Location = new System.Drawing.Point(12, 455);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(141, 39);
            this.btnPrint.TabIndex = 0;
            this.btnPrint.Text = "Печать";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // doc_idTextBox
            // 
            this.doc_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.bsNakladnaya, "doc_id", true));
            this.doc_idTextBox.Enabled = false;
            this.doc_idTextBox.Location = new System.Drawing.Point(102, 28);
            this.doc_idTextBox.Name = "doc_idTextBox";
            this.doc_idTextBox.Size = new System.Drawing.Size(100, 27);
            this.doc_idTextBox.TabIndex = 5;
            // 
            // bsNakladnaya
            // 
            this.bsNakladnaya.DataMember = "nakladnaya";
            this.bsNakladnaya.DataSource = this.zavhoz_dbDataSet;
            // 
            // zavhoz_dbDataSet
            // 
            this.zavhoz_dbDataSet.DataSetName = "zavhoz_dbDataSet";
            this.zavhoz_dbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // doc_dateDateTimePicker
            // 
            this.doc_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.bsNakladnaya, "doc_date", true));
            this.doc_dateDateTimePicker.Location = new System.Drawing.Point(259, 28);
            this.doc_dateDateTimePicker.Name = "doc_dateDateTimePicker";
            this.doc_dateDateTimePicker.Size = new System.Drawing.Size(184, 27);
            this.doc_dateDateTimePicker.TabIndex = 7;
            // 
            // rabotnik_otComboBox
            // 
            this.rabotnik_otComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.bsNakladnaya, "rabotnik_ot", true));
            this.rabotnik_otComboBox.DataSource = this.rabotnikiBindingSource1;
            this.rabotnik_otComboBox.DisplayMember = "fio";
            this.rabotnik_otComboBox.FormattingEnabled = true;
            this.rabotnik_otComboBox.Location = new System.Drawing.Point(102, 80);
            this.rabotnik_otComboBox.Name = "rabotnik_otComboBox";
            this.rabotnik_otComboBox.Size = new System.Drawing.Size(210, 28);
            this.rabotnik_otComboBox.TabIndex = 9;
            this.rabotnik_otComboBox.ValueMember = "rabotnik_id";
            // 
            // rabotnikiBindingSource1
            // 
            this.rabotnikiBindingSource1.DataMember = "rabotniki";
            this.rabotnikiBindingSource1.DataSource = this.zavhoz_dbDataSet;
            // 
            // rabotnik_kComboBox
            // 
            this.rabotnik_kComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.bsNakladnaya, "rabotnik_k", true));
            this.rabotnik_kComboBox.DataSource = this.rabotnikiBindingSource2;
            this.rabotnik_kComboBox.DisplayMember = "fio";
            this.rabotnik_kComboBox.FormattingEnabled = true;
            this.rabotnik_kComboBox.Location = new System.Drawing.Point(429, 80);
            this.rabotnik_kComboBox.Name = "rabotnik_kComboBox";
            this.rabotnik_kComboBox.Size = new System.Drawing.Size(210, 28);
            this.rabotnik_kComboBox.TabIndex = 11;
            this.rabotnik_kComboBox.ValueMember = "rabotnik_id";
            // 
            // rabotnikiBindingSource2
            // 
            this.rabotnikiBindingSource2.DataMember = "rabotniki";
            this.rabotnikiBindingSource2.DataSource = this.zavhoz_dbDataSet;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.dgvNakladnayaPoz);
            this.panel1.Location = new System.Drawing.Point(12, 153);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(778, 289);
            this.panel1.TabIndex = 12;
            // 
            // dgvNakladnayaPoz
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.dgvNakladnayaPoz.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvNakladnayaPoz.AutoGenerateColumns = false;
            this.dgvNakladnayaPoz.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNakladnayaPoz.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.dgvNakladnayaPoz.DataSource = this.nakladnaya_pozBindingSource;
            this.dgvNakladnayaPoz.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvNakladnayaPoz.Location = new System.Drawing.Point(0, 0);
            this.dgvNakladnayaPoz.Name = "dgvNakladnayaPoz";
            this.dgvNakladnayaPoz.RowTemplate.Height = 30;
            this.dgvNakladnayaPoz.Size = new System.Drawing.Size(778, 289);
            this.dgvNakladnayaPoz.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "nakladnaya_poz";
            this.dataGridViewTextBoxColumn1.HeaderText = "nakladnaya_poz";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "doc_id";
            this.dataGridViewTextBoxColumn2.HeaderText = "doc_id";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Visible = false;
            this.dataGridViewTextBoxColumn2.Width = 90;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "inventar_id";
            this.dataGridViewTextBoxColumn3.DataSource = this.inventarBindingSource;
            this.dataGridViewTextBoxColumn3.DisplayMember = "nazvanie";
            this.dataGridViewTextBoxColumn3.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn3.HeaderText = "Инвентарь";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn3.ValueMember = "inventar_id";
            this.dataGridViewTextBoxColumn3.Width = 250;
            // 
            // inventarBindingSource
            // 
            this.inventarBindingSource.DataMember = "inventar";
            this.inventarBindingSource.DataSource = this.zavhoz_dbDataSet;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "kol";
            this.dataGridViewTextBoxColumn4.HeaderText = "Кол-во";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "edizm_id";
            this.dataGridViewTextBoxColumn5.DataSource = this.edizmBindingSource;
            this.dataGridViewTextBoxColumn5.DisplayMember = "nazv";
            this.dataGridViewTextBoxColumn5.DisplayStyle = System.Windows.Forms.DataGridViewComboBoxDisplayStyle.Nothing;
            this.dataGridViewTextBoxColumn5.HeaderText = "Ед. изм.";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dataGridViewTextBoxColumn5.ValueMember = "edizm_id";
            // 
            // edizmBindingSource
            // 
            this.edizmBindingSource.DataMember = "edizm";
            this.edizmBindingSource.DataSource = this.zavhoz_dbDataSet;
            // 
            // nakladnaya_pozBindingSource
            // 
            this.nakladnaya_pozBindingSource.DataMember = "FK__nakladnay__doc_i__21B6055D";
            this.nakladnaya_pozBindingSource.DataSource = this.bsNakladnaya;
            // 
            // nakladnayaTableAdapter
            // 
            this.nakladnayaTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.dolzhnostiTableAdapter = null;
            this.tableAdapterManager.edizmTableAdapter = null;
            this.tableAdapterManager.inventarTableAdapter = null;
            this.tableAdapterManager.nakladnaya_pozTableAdapter = this.nakladnaya_pozTableAdapter;
            this.tableAdapterManager.nakladnayaTableAdapter = this.nakladnayaTableAdapter;
            this.tableAdapterManager.nalichieTableAdapter = null;
            this.tableAdapterManager.rabotnikiTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = zavhoz.zavhoz_dbDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // nakladnaya_pozTableAdapter
            // 
            this.nakladnaya_pozTableAdapter.ClearBeforeFill = true;
            // 
            // rabotnikiBindingSource
            // 
            this.rabotnikiBindingSource.DataMember = "rabotniki";
            this.rabotnikiBindingSource.DataSource = this.zavhoz_dbDataSet;
            // 
            // rabotnikiTableAdapter
            // 
            this.rabotnikiTableAdapter.ClearBeforeFill = true;
            // 
            // inventarTableAdapter
            // 
            this.inventarTableAdapter.ClearBeforeFill = true;
            // 
            // edizmTableAdapter
            // 
            this.edizmTableAdapter.ClearBeforeFill = true;
            // 
            // PeremeschenieForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(802, 506);
            this.Controls.Add(this.panel1);
            this.Controls.Add(rabotnik_kLabel);
            this.Controls.Add(this.rabotnik_kComboBox);
            this.Controls.Add(rabotnik_otLabel);
            this.Controls.Add(this.rabotnik_otComboBox);
            this.Controls.Add(doc_dateLabel);
            this.Controls.Add(this.doc_dateDateTimePicker);
            this.Controls.Add(doc_idLabel);
            this.Controls.Add(this.doc_idTextBox);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "PeremeschenieForm";
            this.Text = "Перемещение инвентаря";
            this.Load += new System.EventHandler(this.PeremeschenieForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bsNakladnaya)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zavhoz_dbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotnikiBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotnikiBindingSource2)).EndInit();
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNakladnayaPoz)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventarBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edizmBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nakladnaya_pozBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rabotnikiBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnPrint;
        private zavhoz_dbDataSet zavhoz_dbDataSet;
        private System.Windows.Forms.BindingSource bsNakladnaya;
        private zavhoz_dbDataSetTableAdapters.nakladnayaTableAdapter nakladnayaTableAdapter;
        private zavhoz_dbDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private zavhoz_dbDataSetTableAdapters.nakladnaya_pozTableAdapter nakladnaya_pozTableAdapter;
        private System.Windows.Forms.TextBox doc_idTextBox;
        private System.Windows.Forms.DateTimePicker doc_dateDateTimePicker;
        private System.Windows.Forms.ComboBox rabotnik_otComboBox;
        private System.Windows.Forms.ComboBox rabotnik_kComboBox;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.BindingSource nakladnaya_pozBindingSource;
        private System.Windows.Forms.DataGridView dgvNakladnayaPoz;
        private System.Windows.Forms.BindingSource rabotnikiBindingSource;
        private zavhoz_dbDataSetTableAdapters.rabotnikiTableAdapter rabotnikiTableAdapter;
        private System.Windows.Forms.BindingSource rabotnikiBindingSource1;
        private System.Windows.Forms.BindingSource rabotnikiBindingSource2;
        private System.Windows.Forms.BindingSource inventarBindingSource;
        private zavhoz_dbDataSetTableAdapters.inventarTableAdapter inventarTableAdapter;
        private System.Windows.Forms.BindingSource edizmBindingSource;
        private zavhoz_dbDataSetTableAdapters.edizmTableAdapter edizmTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewComboBoxColumn dataGridViewTextBoxColumn5;
    }
}