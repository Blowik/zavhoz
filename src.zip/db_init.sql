﻿/*
create table inventar
(
	inventar_id int IDENTITY(1,1) PRIMARY KEY,
	nazvanie nvarchar(64),
	cena decimal (10,2)
);

create table dolzhnosti
(
	dolzhnost_id int IDENTITY(1,1) PRIMARY KEY,
	nazvanie nvarchar(128),
);


create table rabotniki
(
	rabotnik_id int IDENTITY(1,1) PRIMARY KEY,
	fio nvarchar(64),
	dolzhnost_id int references dolzhnosti(dolzhnost_id)
);

create table edizm
(
	edizm_id  int IDENTITY(1,1) PRIMARY KEY,
	nazv nvarchar(32)
);

create table nalichie
(
	id  int IDENTITY(1,1) PRIMARY KEY,
	inventar_id int references inventar(inventar_id),
	rabotnik_id int references rabotniki(rabotnik_id),
	kol int,
	edizm_id int references edizm(edizm_id)
);

create table nakladnaya
(
	doc_id int PRIMARY KEY,
	doc_date date,
	rabotnik_ot int references rabotniki(rabotnik_id),
	rabotnik_k int references rabotniki(rabotnik_id),
);

create table nakladnaya_poz
(
	nakladnaya_poz int IDENTITY(1,1) PRIMARY KEY,
	doc_id int references nakladnaya(doc_id),
	inventar_id int references inventar(inventar_id),
	kol int,
	edizm_id int references edizm(edizm_id)
);


create view nalichie_view as 
(
select id, n.inventar_id, i.nazvanie, n.kol, e.nazv, e.edizm_id , cena, r.fio, r.rabotnik_id  
from nalichie n 
	inner join inventar i on n.inventar_id=i.inventar_id
	inner join rabotniki r on n.rabotnik_id = r.rabotnik_id
	inner join edizm e on n.edizm_id = e.edizm_id
);



create view nacladnaya_view as 
(
	select doc_id, doc_date, n.rabotnik_k, n.rabotnik_ot, r1.fio as r_ot, r2.fio as r_k from nakladnaya n 
		inner join rabotniki r1 on n.rabotnik_ot = r1.rabotnik_id
		inner join rabotniki r2 on n.rabotnik_k = r2.rabotnik_id
);



select * from nacladnaya_view;


select max(doc_id)+1 as id from nakladnaya;



create view nacladnaya_pos_view as (
select n.doc_id, i.nazvanie, n.kol, e.nazv, cena  from nakladnaya_poz n 
	inner join inventar i on n.inventar_id = i.inventar_id 
	inner join edizm e on e.edizm_id = n.edizm_id);
*/


select * from nacladnaya_pos_view;